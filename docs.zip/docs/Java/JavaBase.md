# 🤏Base Java

> 记录一些 Java 开发过程中踩过的坑

```java
const fuck = 10;
```

